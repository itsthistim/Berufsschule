-- ue_db.sql
/*
	T. Hofmann, 23.03.2021
*/

show databases;